from giskard import Model, WrapperModel, SKLearnModel
from abc import abstractmethod, ABC
import pandas as pd

class TestModel(SKLearnModel, ABC):
    def predict_df(df):
        pass
    def clf_predict(df):
        pass
    def load_clf(df):
        pass


if __name__ == "__main__":
    my_model = TestModel(clf=None, model_type='regression')
    print(isinstance(my_model, Model))
