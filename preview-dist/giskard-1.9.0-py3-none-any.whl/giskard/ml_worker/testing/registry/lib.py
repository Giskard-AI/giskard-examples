from dataclasses import dataclass


@dataclass
class Model:
    name: str


@dataclass
class Dataset:
    name: str
