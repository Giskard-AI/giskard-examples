from giskard.ml_worker.testing.tests import heuristic
from giskard.ml_worker.testing.tests import performance

__all__ = [
    'heuristic',
    'performance'
]
